package com.example.stateeventformvalidation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =====================================================
// 1. KONSTANTA WARNA APLIKASI FILOCOFFE
// Warna dibuat tetap agar tampilan konsisten.
// =====================================================

private val Pink = Color(0xFFD63372)
private val PinkLight = Color(0xFFFFF1F3)
private val PinkBorder = Color(0xFFE8A0B0)
private val Brown = Color(0xFF4B2D23)
private val BrownText = Color(0xFF40251F)
private val MutedText = Color(0xFF80635F)
private val White = Color(0xFFFFFFFF)
private val SuccessGreen = Color(0xFF247447)

class MainActivity : ComponentActivity() {

    // Fungsi utama yang pertama kali dijalankan Android.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Menampilkan antarmuka menggunakan Jetpack Compose.
        setContent {
            // Mengatur tema warna utama aplikasi.
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Pink,
                    onPrimary = White,
                    secondary = Brown,
                    background = PinkLight,
                    surface = White,
                    error = Color(0xFFB3261E)
                )
            ) {
                // Memanggil halaman pendaftaran pelanggan.
                RegistrationScreen()
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RegistrationScreen() {

    // =================================================
    // 2. STATE
    // State menyimpan data dan kondisi aplikasi.
    // Ketika nilainya berubah, Compose memperbarui UI.
    // rememberSaveable membantu mempertahankan nilai
    // ketika konfigurasi layar berubah.
    // =================================================

    var nama by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    // Menyimpan status persetujuan ketentuan penggunaan.
    var setuju by rememberSaveable { mutableStateOf(false) }
    // Mengatur apakah password terlihat atau tersembunyi.
    var passwordTerlihat by rememberSaveable { mutableStateOf(false) }
    var konfirmasi by rememberSaveable { mutableStateOf("") }
    var konfirmasiTerlihat by rememberSaveable { mutableStateOf(false) }
    // Menandai apakah tombol daftar sudah pernah ditekan.
    var sudahSubmit by rememberSaveable { mutableStateOf(false) }
    // Menentukan apakah pendaftaran berhasil.
    var berhasil by rememberSaveable { mutableStateOf(false) }

    // =================================================
    // 3. FORM VALIDATION
    // Memeriksa apakah setiap input memenuhi aturan.
    // =================================================
    // Nama tidak boleh kosong atau hanya berisi spasi.
    val namaValid = nama.isNotBlank()
    // Email harus sesuai dengan pola alamat email.
    val emailValid = android.util.Patterns.EMAIL_ADDRESS
        .matcher(email.trim()).matches()
    // Password minimal 8 karakter dan mengandung angka.
    val passwordValid = password.length >= 8 &&
            password.any { it.isDigit() }

    val konfirmasiValid = konfirmasi.isNotEmpty() && konfirmasi == password

    // Form dinyatakan valid jika seluruh syarat terpenuhi.
    val formValid = namaValid &&
            emailValid &&
            passwordValid &&
            setuju

    // =================================================
    // 4. LAYOUT UTAMA
    // Column menyusun komponen dari atas ke bawah.
    // verticalScroll memungkinkan layar digulir.
    // =================================================
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PinkLight)
            .imePadding()
            .verticalScroll(rememberScrollState())
    ) {
        // Header berisi nama aplikasi Filocoffe.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = Brown,
                    shape = RoundedCornerShape(
                        bottomStart = 48.dp,
                        bottomEnd = 48.dp
                    )
                )
                .padding(vertical = 32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Filocoffe",
                color = White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
        }
        // Column untuk judul, input, checkbox, dan tombol.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(top = 28.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Judul halaman pendaftaran.
            Text(
                text = "Daftar Pelanggan Baru",
                color = BrownText,
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold
            )

            // Penjelasan singkat untuk pelanggan.
            Text(
                text = "Bergabunglah bersama kami dan nikmati " +
                        "pengalaman terbaik di Filocoffe.",
                color = MutedText,
                fontSize = 16.sp,
                lineHeight = 24.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // =========================================
            // 5. INPUT NAMA
            // onValueChange merupakan event ketika teks
            // yang diketik pengguna mengalami perubahan.
            // =========================================

            OutlinedTextField(
                value = nama,
                onValueChange = {
                    nama = it
                    berhasil = false
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Nama lengkap") },
                singleLine = true,
                isError = sudahSubmit && !namaValid,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors()
            )

            // Pesan kesalahan muncul setelah tombol daftar
            // ditekan apabila nama belum diisi.
            if (sudahSubmit && !namaValid) {
                ErrorText("Nama lengkap wajib diisi")
            }

            // =========================================
            // 6. INPUT EMAIL
            // Keyboard email memudahkan pengguna mengetik
            // alamat email pada perangkat Android.
            // =========================================

            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    berhasil = false
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Email pelanggan") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                isError = sudahSubmit && !emailValid,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors()
            )

            // Pesan muncul jika format email tidak valid.
            if (sudahSubmit && !emailValid) {
                ErrorText("Masukkan alamat email yang valid")
            }

            // =========================================
            // 7. INPUT PASSWORD
            // Password disamarkan demi privasi pengguna.
            // Ikon mata menjadi event untuk mengubah
            // kondisi password terlihat atau tersembunyi.
            // =========================================
            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    berhasil = false
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Password") },
                singleLine = true,
                // Menentukan cara password ditampilkan.
                visualTransformation = if (passwordTerlihat) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                // Event ketika ikon mata ditekan.
                trailingIcon = {
                    IconButton(
                        onClick = {
                            passwordTerlihat = !passwordTerlihat
                        }
                    ) {
                        Icon(
                            imageVector = if (passwordTerlihat) {
                                Icons.Default.VisibilityOff
                            } else {
                                Icons.Default.Visibility
                            },
                            contentDescription = "Tampilkan atau sembunyikan password",
                            tint = Brown
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                ),

                // Border berubah menjadi error
                // jika password tidak memenuhi aturan.
                isError = sudahSubmit && !passwordValid,
                // Keterangan aturan password.
                supportingText = {
                    if (sudahSubmit && !passwordValid) {
                        Text(
                            "Password minimal 8 karakter dan " +
                                    "harus mengandung minimal 1 angka"
                        )
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors()
            )

            OutlinedTextField(
                value = konfirmasi,
                onValueChange = {
                    konfirmasi = it
                    berhasil = false
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Konfirmasi password") },
                singleLine = true,
                visualTransformation = if (konfirmasiTerlihat) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    IconButton(onClick = { konfirmasiTerlihat = !konfirmasiTerlihat }) {
                        Icon(
                            imageVector = if (konfirmasiTerlihat) {
                                Icons.Default.VisibilityOff
                            } else {
                                Icons.Default.Visibility
                            },
                            contentDescription = "Tampilkan atau sembunyikan konfirmasi password",
                            tint = Brown
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                isError = sudahSubmit && !konfirmasiValid,
                supportingText = {
                    if (sudahSubmit && !konfirmasiValid) {
                        Text("Konfirmasi password harus sama dengan password")
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors()
            )

            // =========================================
            // 8. CHECKBOX PERSETUJUAN
            // Pengguna wajib menyetujui ketentuan
            // sebelum pendaftaran dinyatakan berhasil.
            // =========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Checkbox(
                    checked = setuju,
                    // Event ketika checkbox dicentang
                    // atau tidak dicentang.
                    onCheckedChange = {
                        setuju = it
                        berhasil = false
                    },
                    colors = CheckboxDefaults.colors(
                        checkedColor = Pink,
                        uncheckedColor = Brown
                    )
                )

                Text(
                    text = "Saya menyetujui ketentuan penggunaan",
                    color = BrownText,
                    fontSize = 14.sp
                )
            }

            // Pesan error jika persetujuan belum dicentang.
            if (sudahSubmit && !setuju) {
                ErrorText("Kamu harus menyetujui ketentuan penggunaan")
            }

            Spacer(modifier = Modifier.height(2.dp))

            // =========================================
            // 9. EVENT TOMBOL DAFTAR
            // Saat tombol ditekan, validasi dijalankan.
            // Jika semua syarat terpenuhi, pendaftaran
            // berhasil. Jika tidak, pesan error muncul.
            // =========================================
            Button(
                onClick = {
                    sudahSubmit = true
                    berhasil = formValid
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Brown
                )
            ) {
                Text(
                    text = "Daftar Pelanggan Baru",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // =========================================
            // 10. EVENT TOMBOL ULANGI PENDAFTARAN
            // Mengosongkan seluruh input dan mengembalikan
            // kondisi aplikasi ke keadaan awal.
            // =========================================
            OutlinedButton(
                onClick = {
                    nama = ""
                    email = ""
                    password = ""
                    setuju = false
                    passwordTerlihat = false
                    konfirmasi = ""
                    konfirmasiTerlihat = false
                    sudahSubmit = false
                    berhasil = false
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Pink
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Pink
                )
            ) {
                Text(
                    text = "Ulangi Pendaftaran",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // =========================================
            // 11. FEEDBACK KEBERHASILAN
            // Bagian ini hanya tampil jika seluruh
            // validasi berhasil dipenuhi.
            // =========================================
            if (berhasil) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFFE5F2E8),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Pendaftaran berhasil!",
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )

                        Text(
                            text = "Halo, $nama! Selamat bergabung di Filocoffe.",
                            color = BrownText,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

// =====================================================
// 12. KOMPONEN PESAN ERROR
// Fungsi reusable agar tampilan pesan kesalahan
// konsisten pada setiap kolom formulir.
// =====================================================
@Composable
fun ErrorText(pesan: String) {
    Text(
        text = pesan,
        color = MaterialTheme.colorScheme.error,
        fontSize = 12.sp
    )
}

// =====================================================
// 13. WARNA INPUT
// Mengatur warna border, label, teks, dan latar
// pada seluruh kolom input agar konsisten.
// =====================================================
@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Pink,
    unfocusedBorderColor = PinkBorder,
    focusedLabelColor = Pink,
    unfocusedLabelColor = MutedText,
    cursorColor = Pink,
    focusedTextColor = BrownText,
    unfocusedTextColor = BrownText,
    focusedContainerColor = White,
    unfocusedContainerColor = White
)
